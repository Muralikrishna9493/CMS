package com.church.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChurchVolunteerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
