package com.church.api.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.church.api.entity.MemberEntity;
@Repository
public interface MemberRepo extends JpaRepository<MemberEntity, Long> {

}
