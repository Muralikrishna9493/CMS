package com.church.api.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.church.api.entity.MemberEntity;
import com.church.api.entity.VolunteerEntity;
import com.church.api.repo.MemberRepo;

@Service
public class MemberServiceImp implements MemberService {
	@Autowired
private MemberRepo memberRepo;
	@Override
	public MemberEntity createMember(MemberEntity memberEntity) {
		
			return memberRepo.save(memberEntity);
		
	}

	@Override
	public MemberEntity updateMember(MemberEntity MemberEntity) {
		if(MemberEntity!=null)
			return memberRepo.save(MemberEntity);
		return null;
		
	}

	@Override
	public List<MemberEntity> getAllMember() {
		
		return memberRepo.findAll();
	
	}

	@Override
	public MemberEntity getByMemberId(Long id) {
		Optional<MemberEntity > findById=memberRepo.findById(id);
		if(findById.isEmpty())
			return null;
		MemberEntity memberEntity=findById.get();
		
		return memberEntity;
	}
	@Override
	public String deletemember(Long membership_Id) 
	{
		Optional<MemberEntity> findById=memberRepo.findById(membership_Id);
		if(findById.isEmpty())
			return null;
		MemberEntity taskEntity=findById.get();
		MemberEntity updateTask = memberRepo.save(taskEntity);
		if(updateTask != null)
		{
			memberRepo.deleteById(membership_Id);
			return "Delection successful";
		}
		return "Data is not present in database";
	}
}
