package com.church.api.service;

import java.util.List;

import com.church.api.entity.MemberEntity;

public interface MemberService {

	public MemberEntity createMember(MemberEntity memberEntity);
	public MemberEntity updateMember(MemberEntity memberEntity);
	public List<MemberEntity> getAllMember();
	public MemberEntity getByMemberId(Long id);
	public String deletemember(Long membership_Id);
}
 