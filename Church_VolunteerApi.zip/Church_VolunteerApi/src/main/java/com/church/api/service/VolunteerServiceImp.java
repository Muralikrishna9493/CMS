package com.church.api.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.church.api.entity.VolunteerEntity;
import com.church.api.repo.VolunteerRepo;

@Service
public class VolunteerServiceImp implements VolunteerService {
	@Autowired
private VolunteerRepo volunteerRepo;
	@Override
	public VolunteerEntity createVolunteer(VolunteerEntity volunteerEntity) {
		if(volunteerEntity!=null)
			return volunteerRepo.save(volunteerEntity);
		return null;
	}

	@Override
	public VolunteerEntity updateVolunteer(VolunteerEntity volunteerEntity) {
		if(volunteerEntity!=null)
			return volunteerRepo.save(volunteerEntity);
		return null;
		
	}

	@Override
	public List<VolunteerEntity> getAllVolunteer() {
		
		return volunteerRepo.findAll();
	
	}

	@Override
	public VolunteerEntity getByVolunteerId(Long id) {
		Optional<VolunteerEntity > findById=volunteerRepo.findById(id);
		if(findById.isEmpty())
			return null;
		VolunteerEntity volunteerEntity=findById.get();
		
		return volunteerEntity;
	}

}
