package com.church.api.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.church.api.entity.VolunteerEntity;
@Repository
public interface VolunteerRepo extends JpaRepository<VolunteerEntity, Long> {

}
