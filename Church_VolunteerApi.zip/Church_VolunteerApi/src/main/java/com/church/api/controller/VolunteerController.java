package com.church.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.church.api.entity.VolunteerEntity;
import com.church.api.service.VolunteerService;

@RestController
@CrossOrigin(origins = "http://localhost:3000/")
@RequestMapping("/volunteerApi")

public class VolunteerController {
@Autowired 
private VolunteerService volunteerService;

@PostMapping("/volunteer/create")
public VolunteerEntity createVolunteer(@RequestBody VolunteerEntity volunteerEntity) 
{
	return volunteerService.createVolunteer(volunteerEntity);
}
//@PostMapping("/Volunteer/create")
//public ResponseEntity<VolunteerEntity> createVolunteer(@RequestBody VolunteerEntity volunteerEntity) {
//    VolunteerEntity createdVolunteer = volunteerService.createVolunteer(volunteerEntity);
//    return new ResponseEntity<>(createdVolunteer, HttpStatus.CREATED);
//}

@PutMapping("/volunteer/update")
public VolunteerEntity updateVolunteer(@RequestBody VolunteerEntity volunteerEntity) 
{
	return volunteerService.updateVolunteer(volunteerEntity);
}

@GetMapping("/volunteers")
public List<VolunteerEntity> getAllTask() 
{
	return volunteerService.getAllVolunteer();
}

@GetMapping("/volunteer/{id}")
public VolunteerEntity getByTaskId(@PathVariable Long id) 
{
	return volunteerService.getByVolunteerId(id);
}
}
