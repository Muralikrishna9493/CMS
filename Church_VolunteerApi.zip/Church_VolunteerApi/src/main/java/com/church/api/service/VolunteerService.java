package com.church.api.service;

import java.util.List;

import com.church.api.entity.VolunteerEntity;

public interface VolunteerService {

	public VolunteerEntity createVolunteer(VolunteerEntity volunteerEntity);
	public VolunteerEntity updateVolunteer(VolunteerEntity volunteerEntity);
	public List<VolunteerEntity> getAllVolunteer();
	public VolunteerEntity getByVolunteerId(Long id);
}
 