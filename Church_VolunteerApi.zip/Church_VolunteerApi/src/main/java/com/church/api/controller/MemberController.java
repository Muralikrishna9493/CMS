package com.church.api.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.church.api.entity.MemberEntity;
import com.church.api.entity.MemberEntity;
import com.church.api.service.MemberService;
import com.church.api.service.MemberService;

@RestController
@CrossOrigin(origins = "*")
@Controller
@RequestMapping("/MemberApi")
public class MemberController {
@Autowired 
private MemberService MemberService;

@PostMapping("/memeber/create")
public MemberEntity createMember(@RequestBody MemberEntity memberEntity) 
{
	return MemberService.createMember(memberEntity);
}
//@PostMapping("/Member/create")
//public ResponseEntity<MemberEntity> createMember(@RequestBody MemberEntity memberEntity) {
//    MemberEntity createdVolunteer = MemberService.createMember(MemberEntity);
//    return new ResponseEntity<>(createdMember, HttpStatus.CREATED);
//}
//
//@PutMapping("/Member/update")
//public MemberEntity updateMember(@RequestBody MemberEntity MemberEntity) 
//{
//	return MemberService.updateMember(MemberEntity);
//}
//
//@GetMapping("/Member")
//public List<MemberEntity> getAllTask() 
//{
//	return MemberService.getAllMember();
//}
//
//@GetMapping("/Member/{id}")
//public MemberEntity getByTaskId(@PathVariable Long id) 
//{
//	return MemberService.getByMemberId(id);
//}
//}


    // Update an existing member
    @PutMapping("/update/{id}")
    public ResponseEntity<MemberEntity> updateMember(@PathVariable Long id, @RequestBody MemberEntity updatedMember) {
        MemberEntity existingMember = MemberService.getByMemberId(id);

        if (existingMember != null) {
            updatedMember.setMembership_Id(id);  // Assuming your entity has an 'id' field
            MemberEntity updatedEntity = MemberService.updateMember(updatedMember);
            return new ResponseEntity<>(updatedEntity, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Get all members
    @GetMapping("/getAll")
    public ResponseEntity<List<MemberEntity>> getAllMembers() {
        List<MemberEntity> members = MemberService.getAllMember();
        return new ResponseEntity<>(members, HttpStatus.OK);
    }

    // Get a member by ID
    @GetMapping("/{id}")
    public ResponseEntity<MemberEntity> getMemberById(@PathVariable Long id) {
        MemberEntity member = MemberService.getByMemberId(id);

        if (member != null) {
            return new ResponseEntity<>(member, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping("/member/{memberId}")
	public String deletememeber(@PathVariable Long memberId) 
	{
		return MemberService.deletemember(memberId);
	}
}
